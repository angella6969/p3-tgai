<div class="row mb-3">
    <label class="col-sm-2 col-form-label" for="">{{ $nama }}</label>
    <div class="col-sm-10">
        <div class="input-group input-group-merge">
            <input type="text" class="form-control" disabled value="{{ $nilai }}" />
        </div>
    </div>
</div>
