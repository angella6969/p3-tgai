<div class="col-sm-10">
    <div class="mb-3 col-md-12">
        <label for="{{ $nama }}" class="form-label">{{ $judul }}</label>
        <textarea type="text" class="form-control" id="{{ $nama }}" name="{{ $nama }}"
            placeholder="{{ $placeholder }}" cols="15" rows="3">{{ $nilai }}</textarea>
    </div>
</div>
