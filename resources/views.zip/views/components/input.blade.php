<div class="mb-3">
    <label class="col-sm-2 form-label">{{ $label }}</label>
    <div class="col-sm-10">
        <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="{{ $icon }}"></i></span>
            <input type="text" id="basic-icon-default-phone" class="form-control phone-mask" name="{{ $nama }}"
                required value="{{ $value1 }}" />
        </div>
    </div>
</div>
