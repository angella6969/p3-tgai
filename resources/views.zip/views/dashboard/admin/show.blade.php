@extends('layout.dashboard.main')
@section('container')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Data Pelamar</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic with Icons -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card">
                        <h5 class="card-header">Detail Profil Pelamar</h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <tbody class="table-border-bottom-0">
                                    <tr>
                                        <td colspan="1"><i
                                                class="fab fa-angular fa-lg text-danger me-3"></i><strong>Nama</strong></td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->nama }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="1"><i
                                                class="fab fa-angular fa-lg text-danger me-3"></i><strong>NIK</strong></td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->nik }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="1"><i class="fab fa-angular fa-lg text-danger me-3"></i><strong>No
                                                Hp</strong></td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->nohp }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="1"><i
                                                class="fab fa-angular fa-lg text-danger me-3"></i><strong>Email</strong>
                                        </td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->email }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="1"><i
                                                class="fab fa-angular fa-lg text-danger me-3"></i><strong>Alamat
                                                Domisili</strong></td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->alamatdomisili }}</td>
                                    </tr>
                                    <tr>
                                        <td colspan="1"><i
                                                class="fab fa-angular fa-lg text-danger me-3"></i><strong>Alamat
                                                KTP</strong></td>
                                        <td colspan="1">:</td>
                                        <td colspan="10">{{ $rekrutmen->alamatktp }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">Surat Lamaran</label>
                            <div class="col-sm-10"> {{-- {{ asset('storage/' . substr($berita->url_foto, 6, 6)) }} --}}
                                <img class="img-fluid" src="\img\BingImageOfTheDay.jpg" alt="">
                                {{-- <a href="{{ asset('storage/' . substr($rekrutmen->pdf_lamaran, 6)) }}" target="_blank">show
                                    pdf</a> --}}
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">Ijaza</label>
                            <div class="col-sm-10">
                                <img class="img-fluid" src="\img\Surat_Pernyataan_10_Poin-1.png" alt="">
                                {{-- <a href="{{ asset('storage/' . substr($rekrutmen->pdf_ijazah, 6)) }}" target="_blank">show
                                    pdf</a> --}}
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">KTP</label>
                            <div class="col-sm-10">
                                <a href="{{ asset('storage/' . substr($rekrutmen->pdf_ktp, 6)) }}" target="_blank">show
                                    pdf</a>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">SIM A/C</label>
                            <div class="col-sm-10">
                                <a href="{{ asset('storage/' . substr($rekrutmen->pdf_simAC, 6)) }}" target="_blank">show
                                    pdf</a>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">NPWP</label>
                            <div class="col-sm-10">
                                <a href="{{ asset('storage/' . substr($rekrutmen->pdf_npwp, 6)) }}" target="_blank">show
                                    pdf</a>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 form-label" for="basic-icon-default-message">Surat
                                Pernyataan</label>
                            <div class="col-sm-10">
                                <a href="{{ asset('storage/' . substr($rekrutmen->pdf_pernyataan, 6)) }}"
                                    target="_blank">show
                                    pdf</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
