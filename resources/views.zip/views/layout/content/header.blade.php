



@include('layout.content.navbar')